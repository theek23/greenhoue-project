interface  Timenow {
    void time();
}
