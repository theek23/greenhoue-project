package lk.flex.greenHouse.db;

import lk.flex.greenHouse.model.password;

import java.util.ArrayList;

public class Dataset {

    public static ArrayList<password> passwordsTable = new ArrayList<>();


}
